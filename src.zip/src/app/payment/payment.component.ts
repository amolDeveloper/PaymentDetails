import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import * as PaymentActions from '../store/payment.actions';
import { AppState } from '../store/payment.state';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {

  paymentForm: FormGroup;
  verticalPosition: MatSnackBarVerticalPosition

  constructor(private router: Router, private store: Store<AppState>, private http: HttpClient, private _snackBar: MatSnackBar) { }

  ngOnInit() {
    this.paymentForm = new FormGroup({
      'number': new FormControl(null, [Validators.required]),
      'name': new FormControl(null, [Validators.required]),
      'date': new FormControl(null, [Validators.required, this.cuurentDateValidation]),
      'cvv': new FormControl(null, [this.cvvValidation]),
      'amount': new FormControl(null, [Validators.required, this.amountValidation])
    });
  }

  submit() {
    const message = `Your Payment Details with ${this.paymentForm.value.number} is saved`;
    const action = "Success"
    this.store.dispatch(new PaymentActions.AddPayment(this.paymentForm.value));
    this.http.post('https://my-project-9363f.firebaseio.com/posts.json', this.paymentForm.value)
      .subscribe(responseData => {
        this._snackBar.open(message, action, {
          duration: 2000,
          verticalPosition: 'top'
        });
      })
  }

  goBack() {
    this.router.navigate(['']);
  }

  cuurentDateValidation(control: FormControl): { [s: string]: boolean } {
    let today = new Date();
    let userDate = control.value ? new Date(control.value) : null;
    const timeDiff = userDate ? Math.abs(today.getTime() - userDate.getTime()) : null;
    const diffDays = userDate ? Math.ceil(timeDiff / (1000 * 3600 * 24)) : null;
    if (userDate && userDate < today && diffDays >= 2) {
      return { 'inValidDate': true }
    }
    return null;
  }

  amountValidation(control: FormControl): { [s: string]: boolean } {
    if ((control.value || control.value === 0) && control.value <= 0) {
      return { 'inValidAmount': true }
    }
    return null;
  }

  cvvValidation(control: FormControl): { [s: string]: boolean } {
    if (control.value && control.value.length !== 3) {
      return { 'inValidCode': true }
    }
    return null
  }
}
