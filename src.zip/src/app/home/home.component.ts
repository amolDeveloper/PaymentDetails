import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { Payment } from '../store/payment.model'
import { AppState } from '../store/payment.state';
import * as Actions from '../store/payment.actions';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  title = 'Payment Details';
  payments: Observable<Array<Payment>>
  loading$: Observable<Boolean>;
  error$: Observable<Error>

  constructor(private router: Router, private store: Store<AppState>) {
  }

  routeTo() {
    this.router.navigate(['/payment']);
  }

  ngOnInit() {
    this.payments = this.store.select(store => store.payment.list);
    this.loading$ = this.store.select(store => store.payment.loading);
    this.error$ = this.store.select(store => store.payment.error);

    this.store.dispatch(new (Actions.LoadPaymentAction));
  }

}
