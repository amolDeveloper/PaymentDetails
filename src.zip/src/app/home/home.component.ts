import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { Payment } from '../store/payment.model'
import { AppState } from '../store/payment.state';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  title = 'Payment Details';
  payments: Observable<Payment[]>

  constructor(private router: Router, private store: Store<AppState>) {
    this.payments = store.select('payment');
  }

  routeTo() {
    this.router.navigate(['/payment']);
  }

  ngOnInit() {
  }

}
