import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PaymentserviceService {

  constructor(private http: HttpClient) { }

  postPaymentDetails(data) {
    return this.http.post('https://my-project-9363f.firebaseio.com/posts.json', data)
  }

  getPaymentDetails() {
    return this.http.get('https://my-project-9363f.firebaseio.com/posts.json')
  }
}
