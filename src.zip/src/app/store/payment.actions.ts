import { Action } from '@ngrx/store';
import { Payment } from './payment.model';

export enum PaymentActionTypes {
    LOAD_PAYMENT = '[PAYMENT] Load Payment',
    LOAD_PAYMENT_SUCCESS = '[PAYMENT] Load Payment Success',
    LOAD_PAYMENT_FAILURE = '[PAYMENT] Load Payment Failure'
}

export class LoadPaymentAction implements Action {
    readonly type = PaymentActionTypes.LOAD_PAYMENT
}

export class LoadPaymentSuccessAction implements Action {
    readonly type = PaymentActionTypes.LOAD_PAYMENT_SUCCESS

    constructor(public payload: Array<Payment>) { }

}
export class LoadPaymentFailureAction implements Action {
    readonly type = PaymentActionTypes.LOAD_PAYMENT_FAILURE

    constructor(public payload: Error) { }
}

export type PaymentAction = LoadPaymentAction |
    LoadPaymentSuccessAction |
    LoadPaymentFailureAction


