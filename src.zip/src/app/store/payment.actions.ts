import { Action } from '@ngrx/store';
import { Payment } from './payment.model';

export enum PaymentActionTypes {
    LOAD_PAYMENT = '[PAYMENT] Load Payment',
    LOAD_PAYMENT_SUCCESS = '[PAYMENT] Load Payment Success',
    LOAD_PAYMENT_FAILURE = '[PAYMENT] Load Payment Failure',
    ADD_PAYMENT = '[PAYMENT] Add Payment',
    ADD_PAYMENT_SUCCESS = '[PAYMENT] Add Payment Success',
    ADD_PAYMENT_FAILURE = '[PAYMENT] Add Payment Failure'
}

export class LoadPaymentAction implements Action {
    readonly type = PaymentActionTypes.LOAD_PAYMENT
}

export class LoadPaymentSuccessAction implements Action {
    readonly type = PaymentActionTypes.LOAD_PAYMENT_SUCCESS

    constructor(public payload: Array<Payment>) { }

}
export class LoadPaymentFailureAction implements Action {
    readonly type = PaymentActionTypes.LOAD_PAYMENT_FAILURE

    constructor(public payload: Error) { }
}

export class AddPaymentAction implements Action {
    readonly type = PaymentActionTypes.ADD_PAYMENT

    constructor(public payload: Payment) { }
}
export class AddPaymentSuccessAction implements Action {
    readonly type = PaymentActionTypes.ADD_PAYMENT_SUCCESS

    constructor(public payload: Payment) { }
}
export class AddPaymentFailureAction implements Action {
    readonly type = PaymentActionTypes.ADD_PAYMENT_FAILURE

    constructor(public payload: Error) { }
}

export type PaymentAction = LoadPaymentAction |
    LoadPaymentSuccessAction |
    LoadPaymentFailureAction |
    AddPaymentAction |
    AddPaymentSuccessAction |
    AddPaymentFailureAction


