import { PaymentState } from './payment.reducer';

export interface AppState {
    readonly payment: PaymentState
}