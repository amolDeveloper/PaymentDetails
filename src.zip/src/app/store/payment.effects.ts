import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import * as PaymentActions from './payment.actions';
import { PaymentserviceService } from '../paymentservice.service';
import { mergeMap, map, catchError } from 'rxjs/operators';


@Injectable()
export class paymentEffects {

    constructor(private actions$: Actions, private payservice: PaymentserviceService) { }

    @Effect() loadShopping$ = this.actions$
        .pipe(
            ofType<PaymentActions.LoadPaymentAction>(PaymentActions.PaymentActionTypes.LOAD_PAYMENT),
            mergeMap(
                () => this.payservice.getPaymentDetails()
                    .pipe(
                        map(data => {
                            const paymentArray = [];
                            for (const key in data) {
                                if (data.hasOwnProperty(key)) {
                                    paymentArray.push(data[key]);
                                }
                            }
                            console.log('amol')
                            console.log(paymentArray);
                            return new PaymentActions.LoadPaymentSuccessAction(paymentArray)
                        }),
                        catchError(error => of(new PaymentActions.LoadPaymentFailureAction(error)))
                    )
            ),
        )

    @Effect() addShoppingItem$ = this.actions$
        .pipe(
            ofType<PaymentActions.AddPaymentAction>(PaymentActions.PaymentActionTypes.ADD_PAYMENT),
            mergeMap(
                (data) => this.payservice.postPaymentDetails(data.payload)
                    .pipe(
                        map(() => new PaymentActions.AddPaymentSuccessAction(data.payload)),
                        catchError(error => of(new PaymentActions.AddPaymentFailureAction(error)))
                    )
            )
        )

}