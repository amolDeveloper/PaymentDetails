import * as Actions from './payment.actions';
import { Payment } from './payment.model';

export interface PaymentState {
    list: Payment[],
    loading: boolean,
    error: Error
}

const initialState: PaymentState = {
    list: [],
    loading: false,
    error: undefined
};

export function reducer(state: PaymentState = initialState, action: Actions.PaymentAction) {
    switch (action.type) {
        case Actions.PaymentActionTypes.LOAD_PAYMENT:
            return {
                ...state,
                loading: true
            }
        case Actions.PaymentActionTypes.LOAD_PAYMENT_SUCCESS:
            return {
                ...state,
                list: action.payload,
                loading: false
            }

        case Actions.PaymentActionTypes.LOAD_PAYMENT_FAILURE:
            return {
                ...state,
                error: action.payload,
                loading: false
            }

        case Actions.PaymentActionTypes.ADD_PAYMENT:
            return {
                ...state,
                loading: true
            }
        case Actions.PaymentActionTypes.ADD_PAYMENT_SUCCESS:
            return {
                ...state,
                list: [...state.list, action.payload],
                loading: false
            };
        case Actions.PaymentActionTypes.ADD_PAYMENT_FAILURE:
            return {
                ...state,
                error: action.payload,
                loading: false
            };
        default:
            return state;
    }
}